/*
 * Copyright (c) 2020 4dreplay Co., Ltd.
 * All rights reserved.
 */

import UIKit
class BaseViewController : UIViewController {
    @IBOutlet weak var blockView: UIView!
    @IBOutlet weak var blockLabel: UILabel!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    //MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if blockView != nil {
            blockView.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        closeIndicator()
    }
    
    //MARK: Pirvate method
    func initVariable() {
    }
    func setupLayout() {
    }
    
    func showIndicator() {
        NSLog("\(#function)")
        if blockView != nil {
            blockView.isHidden = false
            view.bringSubviewToFront(blockView)
        }
        if  indicator != nil {
            indicator.isHidden = false
            indicator.startAnimating()
        }
    }
    
    func closeIndicator() {
        if blockView != nil {
            blockView.isHidden = true
        }
        if indicator != nil {
            indicator.isHidden = true
            indicator.stopAnimating()
        }
    }
    
    func showMessageAlert(message: String, title: String) {
        let controller = UIAlertController.init(title: title ,
                                                message: message ,
                                                preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default) {(action) in
        }
        controller.addAction(okAction)
        self.present(controller, animated: true, completion: nil)
    }
}
