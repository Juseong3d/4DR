/*
* Copyright (c) 2020 4dreplay Co., Ltd.
* All rights reserved.
*/

import UIKit

class FDThumbSlider : UISlider {
    override func thumbRect(forBounds bounds: CGRect, trackRect rect: CGRect, value: Float) -> CGRect {
        let unadjustedRect = super.thumbRect(forBounds: bounds, trackRect: rect, value: value)
        let offset: CGFloat = unadjustedRect.size.width / 2.0
        let minOffset = -offset
        let maxOffset = offset
        let value = minOffset + (maxOffset - minOffset) * CGFloat(value / (self.maximumValue - self.minimumValue))
        var origin = unadjustedRect.origin
        origin.x += value
        return CGRect(origin: origin, size: unadjustedRect.size)
    }
}

@objc protocol ProgressViewDelegate: AnyObject {
    @objc optional func sliderMoveBegin(_ slider: UISlider)
    @objc optional func sliderMoveEnd(_ slider: UISlider, time: Float, base: Float)
}

class ProgressView: UIView {
    
    @IBOutlet weak var delegate: ProgressViewDelegate?
    @IBOutlet weak var slider: FDThumbSlider!
    @IBOutlet weak var lbDuration: UILabel!
    @IBOutlet weak var lbPostion: UILabel!
    @IBOutlet weak var ivLive: UIImageView!
    @IBOutlet weak var btPlay: UIButton!
    @IBOutlet weak var btPlayToNow: UIButton!
        
    var isTouch: Bool = false
    private var max: Int = 3 * 60
    var pauseTime: Int32 = 0
    
    // MARK: - Life cycle        
    override func awakeFromNib() {
        initVariable()
    }
    
    private func initVariable() {
        let image = UIImage(named: "progress_control")
        slider.setThumbImage(image, for: UIControl.State.normal)
        slider.addTarget(self, action: #selector(sliderTouchBegan(_:)), for: UIControl.Event.touchDown)
        slider.addTarget(self, action: #selector(sliderTouchEnd(_:)), for: UIControl.Event.touchUpInside)
        slider.addTarget(self, action: #selector(sliderTouchDrag(_:)), for: UIControl.Event.touchDragInside)
        
        slider.value = 1.0
        lbDuration.text = ""
        btPlayToNow.isHidden = true
    }
    
    // MARK: - Private method
    @objc func sliderTouchBegan(_ sender: UISlider) {
        //print("\(#function)")
        isTouch = true
        guard let target = delegate else { return }
        if (target.sliderMoveBegin != nil) {
            target.sliderMoveBegin?(slider)
        }
    }
    
    @objc func sliderTouchDrag(_ sender: UISlider) {
        //print("\(#function) value: \(sender.value)")
    }
    
    @objc func sliderTouchEnd(_ sender: UISlider) {
        isTouch = false
        var value: Float = 0
        let time = (1 - slider.value) * Float(max)
        value = Float(pauseTime) - (time * 1000)
        updatePlayTime(Int32(value))
        //print("\(#function) pause time: \(duration) value: \(value) time: \(time)")
                        
        guard let target = delegate else { return }
        if target.sliderMoveEnd != nil {
            target.sliderMoveEnd?(slider, time: value, base: Float(max))
        }
    }
        
    private func updatePlayTime(_ value: Int32) {
        let sign = Int(value).signum()
        let seconds = abs(value)/1000
        var ms = NSMutableString.init(capacity: 6)
        let m = seconds / 60 % 60
        let s = seconds % 60

        if sign > 0 {
            ms = "00:00"
        } else {
            if sign < 0 { ms = "- " }
            if m < 10 { ms.append("0") }
            ms.appendFormat("%d:", m)
            if s < 10 { ms.append("0") }
            ms.appendFormat("%d", s)
        }
        DispatchQueue.main.async { [weak self] in
            self?.lbDuration.text = ms as String
        }
    }
    
    // MARK: - Public method
    func setTimemachineMode(_ isTimemachine: Bool) {
        if isTimemachine == true {
            btPlayToNow.isHidden = false
            ivLive.isHidden = true
        } else {
            btPlayToNow.isHidden = true
            ivLive.isHidden = false
        }
    }
    
    func setCameraPosition(_ string: String) {
        lbPostion.text = string
    }
    
    func setPlayTime(_ time: Int32) {
        if isTouch == true {return}
        if time > 0 {
            let temp = time - pauseTime
            updatePlayTime(temp)
            let ret = Float(pauseTime) - Float(time)
            if ret <= 0 {
                slider.value = 1
            } else {
                let value = (ret / 1000.0) / Float(max)
                slider.value = (1 - value)
            }
            
        } else {
            slider.value = 0
            lbDuration.text = ""
        }
    }
    
    func setupPlayToNow() {
        slider.value = 1
        lbDuration.text = ""
    }
}
