/*
* Copyright (c) 2020 4dreplay Co., Ltd.
* All rights reserved.
*/

import UIKit

class MultiContainView: UIView {

    @IBOutlet weak var btFirst: UIButton!
    @IBOutlet weak var btSecond: UIButton!
    @IBOutlet weak var btThird: UIButton!
    @IBOutlet weak var btFourth: UIButton!
    @IBOutlet weak var btFifth: UIButton!
    @IBOutlet weak var btSixth: UIButton!
    @IBOutlet weak var btSeventh: UIButton!
    @IBOutlet weak var btEighth: UIButton!
    @IBOutlet weak var btNinth: UIButton!
    @IBOutlet weak var btTenth: UIButton!
    
    func updateSelected(_ tag: Int){
        let views = self.subviews
        for view in views {
            let aTag = view.tag
            if aTag > 0 && aTag < 11 && tag != aTag {
                if let button = view as? UIButton {
                    button.isSelected = false
                }
            }
        }
    }
}
 
