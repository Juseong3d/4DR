/*
* Copyright (c) 2020 4dreplay Co., Ltd.
* All rights reserved.
*/

import UIKit

class ContainView: UIScrollView {
    
    override func awakeFromNib() {
        self.initVariable()
    }
    
    func initVariable() {
        self.isScrollEnabled = false
        self.showsHorizontalScrollIndicator = false
        self.showsVerticalScrollIndicator = false
        self.minimumZoomScale = 1.0
        self.maximumZoomScale = 10.0
    }
}
