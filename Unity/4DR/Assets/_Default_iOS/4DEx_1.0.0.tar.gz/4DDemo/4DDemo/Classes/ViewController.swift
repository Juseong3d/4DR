/*
 * Copyright (c) 2020 4dreplay Co., Ltd.
 * All rights reserved.
 */

import UIKit

enum PadTouch: Int {
    case end
    case begin
}

enum Pads: Int {
    case swipe
    case time
}

enum CameraPostion: Int {
    case batter = 1
    case peacher
    case firstBase
    case secondBase
    case thirdBase
    case batteryCut
    case outFieldLeft
    case outFieldRight
    case dogoutLeft
    case dogoutRight
}

class ViewController: BaseViewController, UIScrollViewDelegate {

    @IBOutlet weak var vMainContain: ContainView!
    @IBOutlet weak var vMultiContain: MultiContainView!
    @IBOutlet weak var vBroadcast: UIView!
    @IBOutlet weak var vProgress: ProgressView!
    @IBOutlet weak var swipePad: ControlPad!
    @IBOutlet weak var timePad: ControlPad!
    
    var didRequestCompletion: ( [String: String]? ) -> () = { items in }
    
    private var multiPlayer: FDLivePlayer!
    private var mainPlayer: FDLivePlayer!
    private var thread: Thread?
    private var timer: Timer?
    private var padState: Int = 0
    private var distanceX: CGFloat = 0.0
    private var distanceY: CGFloat = 0.0
    private var isPlaying = false
    private var isOpened = false
    private var isClose = false
    private var isTimeShift = false
    private var isPlayToNow = true
    private var pauseTime: Int32 = 0
    
    @IBOutlet weak var broadViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var broadViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var multiViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var multiViewWidthConstraint: NSLayoutConstraint!
        
    deinit{
        thread?.cancel()
        thread = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initVariable()
        setupPlayer()
        closeIndicator()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showIndicator()
        //self.requestAddress("live", contentID: "live") for live
        self.requestAddress("vod", contentID: "tmobile") //for vod test
        self.didRequestCompletion = {items in
            if items != nil {
                let url = items?["value"]
                DispatchQueue.main.async { [weak self] in
                    self?.onOpen(url)
                    self?.beginTimer()
                }
            }
        }        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isClose = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
        /* Destroy FDLivePlayer */
        onClose(nil)
        isClose = true
    }
    
    // MARK: - Private
    override func initVariable() {
        FDLiveSettings.sharedInstance().set("LOG_LEVEL", string: "DEBUG")
        FDLiveSettings.sharedInstance().set("TIMEOUT_MS", integer: 1000*30)
        
        vMainContain.delegate = self
        swipePad.tag = Pads.swipe.rawValue
        timePad.tag = Pads.time.rawValue
        timePad.isHidden = true
        vMultiContain.btSecond.isSelected = true
    }
    
    private func setupPlayer() {
        /* FDLPlayer */
        var rect = vMainContain.frame
        mainPlayer = FDLivePlayer.init(delegate: self)
        mainPlayer.playerView.frame = rect
        mainPlayer.playerView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        vMainContain.addSubview(mainPlayer.playerView)
        
        let recognizer = UITapGestureRecognizer.init(target: self, action: #selector(taptHandler(_:)))
        recognizer.cancelsTouchesInView = false
        mainPlayer.playerView.addGestureRecognizer(recognizer)
                
        /* broad PIP player */
        if self.view.frame.height > 375 {
            broadViewWidthConstraint.constant = 256
            broadViewHeightConstraint.constant = 144
            multiViewWidthConstraint.constant = 256
            multiViewHeightConstraint.constant = 144
            rect.origin.x = 0
            rect.origin.y = 0
            rect.size.width = 256
            rect.size.height = 144
        } else {
            rect = vMultiContain.bounds
        }
        multiPlayer = FDLivePlayer.init(delegate: self)
        multiPlayer.playerView.frame = rect
        vMultiContain.insertSubview(multiPlayer.playerView, at: 0)
    }
    
    private func onOpen(_ url: String?) {
        if url == nil { return }
        
        var ret = -1
        showIndicator()
        
        var strUrl = url /* rtsp address */
        let aUrl = NSURL(string: url!)
        let strIP = "http:\(aUrl?.host ?? "")" /* live server address */
        let port = 7070 /* Server port number */
        
        /* main player view */
        ret = Int(mainPlayer.streamOpen(strUrl!, isTCP: true, isHWAccel: true));//MARK: Open()
        print("rtsp address: \(String(describing: strUrl))")
        if ret != 0 { closeIndicator() }
        ret = Int(mainPlayer.restFulOpen(strIP, port: port))
        if ret != 0 { closeIndicator() }
                
        /* multi view */
        strUrl = "\(strUrl ?? "")&group=6"
        ret = Int(multiPlayer.streamOpen(strUrl!, isTCP: true, isHWAccel: true));//MARK: Open()
        if ret != 0 { closeIndicator() }
        ret = Int(multiPlayer.restFulOpen(strIP, port: port))
        if ret != 0 { closeIndicator() }
    }
    
    private func onClose(_ sender: Any? = nil) {
        mainPlayer.streamClose()
        multiPlayer.streamClose()
    }
    
    // MARK: - Button action
    @IBAction func playButtonTouchUpInside(_ sender: Any) {
        let button = sender as! UIButton;
        if  button.isSelected == false {
            /* pause */
            button.isSelected = true
            mainPlayer.pause()
            isTimeShift = true
            timePad.isHidden = false
            if isPlayToNow == true {
                vProgress.pauseTime = pauseTime
            }
            isPlayToNow = false
            vProgress.setTimemachineMode(true)
        } else {
            /* play */
            button.isSelected = false
            mainPlayer.play()
            isTimeShift = false
            timePad.isHidden = true
        }
        beginTimer()
    }
    
    @IBAction func nowButttonTouchUpInside(_ sender: Any) {
        mainPlayer.playToNow()
        isTimeShift = false
        timePad.isHidden = true
        vProgress.setupPlayToNow()
        isPlayToNow = true
        vProgress.setTimemachineMode(false)
        vProgress.btPlay.isSelected = false
        beginTimer()
    }
    
    @IBAction func closeButtonTouchUpInside(_ sender: Any) {
        vMultiContain.isHidden = true
    }
    
    @IBAction func showbuttonTouchUpInside(_ sender: Any) {
        vMultiContain.isHidden = false
    }
        
    @IBAction func postionButtonTouchUpInside(_ sender: Any) {
        let button = sender as! UIButton;
        button.isSelected = true
        let tag = CameraPostion(rawValue: button.tag)!
        var string = ""
        var group = ""
        var isSwipe = true
        
        switch tag {
        case .batter:
            string = "Batter"
            group = "2"
            isSwipe = true
            break
        case .peacher:
            string = "Peacher"
            group = "1"
            isSwipe = true
            break
        case .firstBase:
            string = "1st base"
            group = "3"
            isSwipe = true
            break
        case .secondBase:
            string = "2st base"
            group = "4"
            isSwipe = true
            break
        case .thirdBase:
            string = "3st base"
            group = "5"
            isSwipe = true
            break
        case .batteryCut:
            string = "Bettery cut"
            group = "7" //for vod sample
            isSwipe = false
            break
        case .outFieldLeft:
            string = "Out field Left"
            group = "8"
            isSwipe = false
            break
        case .outFieldRight:
            string = "Out field Right"
            group = "9"
            isSwipe = false
            break
        case .dogoutLeft:
            string = "Dogout"
            group = "10" //for vod sample, front peacher
            isSwipe = false
            break
        case .dogoutRight:
            string = "Dogout"
            group = "11" // for vod sample, catcher
            isSwipe = false
            break
        }
        
        swipePad.isEnable = isSwipe
        vProgress.setCameraPosition(string)
        vMultiContain.updateSelected(button.tag)
        mainPlayer.setPositionChange(group)
    }
        
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return mainPlayer.playerView
    }
    
    // MARK: - Gesture recognizer
    @objc func taptHandler(_ recognizer: UITapGestureRecognizer) {
        vProgress.isHidden = !vProgress.isHidden
        vProgress.isHidden ? invalidateTimer() : beginTimer()
    }
    
    private func beginTimer() {
        invalidateTimer()
        timer = Timer.scheduledTimer(timeInterval: 10, target: self,
                                     selector: #selector(onTick(timer:)), userInfo: nil, repeats: false)
    }
    
    private func invalidateTimer() {
        if timer != nil {
            timer?.invalidate()
            timer = nil
        }
    }
    
    @objc private func onTick(timer: Timer) {
        vProgress.isHidden = true
        //print("\(#function)")
    }
    
    // MARK: - ControlPad Delegate
    @objc func moveBegin(_ pad: ControlPad) {
        if isOpened != true {
            //print("It is not open yet.")
            return
        }
        
        padState |= PadTouch.begin.rawValue << pad.tag
        if padState != 0 && thread == nil {
            thread = Thread.init(target: self, selector: #selector(onEventThread(_:)), object: nil)
            thread?.start()
            print("\(#function) \(pad) thread start.")
        }
        invalidateTimer()
    }
    
    @objc func moveEnd(_ pad: ControlPad) {
        if isOpened != true {
            //print("It is not open yet.")
            return
        }
        padState &= ~(PadTouch.begin.rawValue << pad.tag)
        if padState == 0 && thread != nil {
            thread?.cancel()
            thread = nil
            swipePad.clearEvent()
            timePad.clearEvent()
            //print("\(#function) \(pad) thread stop.")
        }
        beginTimer()
    }
    
    @objc func onEventThread(_ sender: Any) {
        //print("\(#function) !!! ")
        autoreleasepool {
            repeat {
                if  self.thread == nil || self.thread!.isCancelled {
                    break
                }
                let interval = 0.04
                let frame = 1
                let swipe = self.swipePad.getEvent()
                let time = self.timePad.getEvent()
                if swipe != nil && time == nil { // swipe
                    if swipe ==  DirectionToPad.right.rawValue {
                            _ = (isTimeShift == true) ? mainPlayer.setChangeFrameCh("pause", direction:"right")
                            : mainPlayer.setChangeChannel("normal", direction: "right", moveFrame:frame)
                    }
                    if swipe ==  DirectionToPad.left.rawValue {
                            _ = (isTimeShift == true) ? mainPlayer.setChangeFrameCh("pause", direction:"left")
                            : mainPlayer.setChangeChannel("normal", direction: "left", moveFrame:frame)
                    }
                }
                //left backward  right forward
                if time != nil && swipe == nil { // timeshift
                    if time ==  DirectionToPad.left.rawValue {
                        mainPlayer.setChangeFrameCh("rewind", direction:"stop") /* down */
                    }
                    if time ==  DirectionToPad.right.rawValue {
                        mainPlayer.setChangeFrameCh("forward", direction:"stop") /* up */
                    }
                }
                if time != nil && swipe != nil { // swipe & time shift
                    if time ==  DirectionToPad.left.rawValue
                        && swipe! & DirectionToPad.left.rawValue ==  DirectionToPad.left.rawValue {
                        mainPlayer.setChangeFrameCh("rewind", direction:"left") /* left & left */
                    }
                    if time ==  DirectionToPad.left.rawValue
                        && swipe! & DirectionToPad.right.rawValue ==  DirectionToPad.right.rawValue {
                        mainPlayer.setChangeFrameCh("rewind", direction:"right") /* right & right*/
                    }
                    if time ==  DirectionToPad.right.rawValue && swipe ==  DirectionToPad.left.rawValue {
                        mainPlayer.setChangeFrameCh("forward", direction:"left") /* up & up*/
                    }
                    if time ==  DirectionToPad.right.rawValue && swipe ==  DirectionToPad.right.rawValue {
                        mainPlayer.setChangeFrameCh("forward", direction:"right") /* up & up */
                    }
                }
                Thread.sleep(forTimeInterval: interval)
            } while true
        }
        
        Thread.exit()
    }

    // MARK: - ProgressView delegate
    @objc func sliderMoveBegin(_ slider: UISlider) {
        invalidateTimer()
    }
    
    @objc func sliderMoveEnd(_ slider: UISlider, time: Float, base: Float) {
        //print("\(slider) time: \(time)")
        if mainPlayer != nil {
            mainPlayer.seek(Int(time))
        }
        beginTimer()
    }
}
    
// MARK: - FDLivePlayer Delegate
extension ViewController:  FDPlayerDelegate{
    
    func getCurrentPlayInfo(_ player:FDLivePlayer, channel: Int32, frame: Int32,
                            frameCycle: Int32, time: Int32, utc: String) {
        //print("channel: \(channel), frame: \(frame) cycle: \(frameCycle) time: \(time) tuc: \(utc)")
        DispatchQueue.main.async { [weak self] in
            if player == self?.mainPlayer {
                if self?.isPlayToNow == true {
                    self?.pauseTime = time
                } else {
                    self?.vProgress.setPlayTime(time)
                }
            }
        }
    }
    
    func getVideoStreamInfo(_ player:FDLivePlayer, width: Int32, height: Int32, duration: Int32) {
        print("\(#function) width: \(width) height: \(height) duration: \(duration).")
    }
    
    func getStart(_ player:FDLivePlayer, code: Int32) {
        print("\(#function) code: \(code).")
        if player == self.mainPlayer {
            if code == 0 {
                isOpened = true
            }
            DispatchQueue.main.async {[weak self] in
                self?.closeIndicator()
            }
        }
    }
    
    func getStop(_ player:FDLivePlayer, code: Int32) {
        print("\(#function) code: \(code).")
        isPlaying = false
        if isClose == true {
            mainPlayer = nil
            multiPlayer = nil
        }
    }
    
    func getPlay(_ player:FDLivePlayer) {
        if player == self.mainPlayer {
            isPlaying = true
        }
    }
    
    func getPause(_ player:FDLivePlayer) {
        print("\(#function)")
        if player == self.mainPlayer {
            isPlaying = false
        }
    }
    
    func getPlayDone(_ player:FDLivePlayer) {
        print("\(#function)")
        if player == self.mainPlayer {
            isPlaying = false
        }
    }
    
    func getError(_ player:FDLivePlayer, code: Int32, message: String) {
        print("\(#function) code: \(code) message: \(message)")
        DispatchQueue.main.async {[weak self] in
            guard let self = self else {return}
            self.closeIndicator()
            if code == FD_ERR_NET_5001.rawValue {
                self.showMessageAlert(message: message, title: "BirdView")
            } else {
                self.showMessageAlert(message: message, title: "Error")
            }
        }
    }
}

// MARK: - Network
extension ViewController {
    /*
     * Request rtsp streaming url.
     */
    func requestAddress(_ type: String, contentID: String) {
        let url = URL(string: "http://18.221.15.123:8070/service/4dss/url?type=\(type)&id=\(contentID)")
        guard let requestUrl = url else { fatalError() }

        var request = URLRequest(url: requestUrl)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error took place \(error)")
                return
            }
            if data != nil {
                let ret = try? JSONSerialization.jsonObject(with: data!, options: []) as? [String : String]
                self.didRequestCompletion(ret)
            } else {
                self.didRequestCompletion(nil)
            }
            
        }
        task.resume()
    }
}
