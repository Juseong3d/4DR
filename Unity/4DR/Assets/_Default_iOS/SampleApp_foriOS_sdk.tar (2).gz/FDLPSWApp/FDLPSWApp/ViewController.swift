/*
 * Copyright (c) 2019-2020 4dreplay Co., Ltd.
 * All rights reserved.
 */

import UIKit

let IS_SUPPORT_ZAPPING = false
let IS_SUPPORT_AWS = true

func LOGD(filePath: String = #file, line: Int = #line, funcName: String = #function, output:Any...) {
    #if DEBUG
    let now = NSDate()
    let app = Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String
    let fileName = URL(fileURLWithPath: filePath).lastPathComponent
    print("\(now.description) \(app)] ##### - [\(fileName) \(funcName)][Line \(line)] \(output)")
    #endif
}

class ViewController: UIViewController, FDPlayerDelegate, UITextFieldDelegate {
    private var fdlPlayer: FDLivePlayer!
    private var currentTextField: UITextField!
    private var isTimeShift = false
    private var isPlaying = false
    private var isClose = false
    private var distanceX: CGFloat = 0.0
    private var distanceY: CGFloat = 0.0
    
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var ipTextField: UITextField!
    @IBOutlet weak var portTextField: UITextField!
    @IBOutlet weak var urTextField: UITextField!
    @IBOutlet weak var modeButton: UIButton!
    @IBOutlet weak var swipTypeLabel: UILabel!
    @IBOutlet weak var tsDirectButton: UIButton!
    @IBOutlet weak var tsDirectLabel: UILabel!
    @IBOutlet weak var seekTextField: UITextField!
    @IBOutlet weak var speedTextField: UITextField!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var chLabel: UILabel!
    @IBOutlet weak var cycleLabel: UILabel!
    @IBOutlet weak var frameLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var duration: UILabel!
    
    //MARK: - Life cycle
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self)
        /* Destroy FDLivePlayer */
        onClose(nil)
        isClose = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        LOGD(output: "Memory warning")
        self.showMessageAlert(message: "Memory warnig!!!", title: "")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initVariable()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.setupPlayer()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isClose = false
    }
    
    private func initVariable() {
        FDLiveSettings.sharedInstance().set("LOG_LEVEL", string: "NONE")
        FDLiveSettings.sharedInstance().set("TIMEOUT_MS", integer: 1000*60)
        
        playButton.isHidden = true;
        ipTextField.isEnabled = false
        urTextField.isEnabled = false
        portTextField.isEnabled = false
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(noti:)),
                                               name:UIResponder.keyboardWillShowNotification , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(noti:)),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(orientationChanged(noti:)),
                                               name: UIDevice.orientationDidChangeNotification,
                                               object: UIDevice.current)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(enterForeground(noti:)),
                                               name: UIApplication.willEnterForegroundNotification,
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(enterBackground(noti:)),
                                               name: UIApplication.didEnterBackgroundNotification,
                                               object: nil)
        let recongizer = UITapGestureRecognizer.init(target: self, action: #selector(tapHander(handler:)))
        self.view.addGestureRecognizer(recongizer)
        
        let keyboardToolbar = UIToolbar.init()
        keyboardToolbar.sizeToFit()
        let flexBarButton = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace,
                                                 target: nil, action: nil)
        let doneBarButton = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.done,
                                                 target: self, action: #selector(onTextFieldDoneButton(sender:)))
        keyboardToolbar.items = [flexBarButton, doneBarButton]
        seekTextField.inputAccessoryView = keyboardToolbar;
        speedTextField.inputAccessoryView = keyboardToolbar;
    }
    
    private func setupPlayer() {
        /* It is sample url, write a url to play. */
        let strUrl = "rtsp://RTSP Address." /* RTSP Address */
        let strIP = "http://255.255.0.0"    /* Server IP Address */
        let port = 1000 /* Server port number */
        /* FDLPlayer */
        fdlPlayer = FDLivePlayer.init(delegate: self)
        fdlPlayer.playerView.frame = playerView.bounds
        playerView.addSubview(fdlPlayer.playerView)
        fdlPlayer.streamOpen(strUrl, isTCP: true, isHWAccel: false);
        fdlPlayer.restFulOpen(strIP, port: port)
        
        let recognizer = UIPanGestureRecognizer.init(target: self, action: #selector(panRecognized(_: )))
        fdlPlayer.playerView.addGestureRecognizer(recognizer)
        let playerTap = UITapGestureRecognizer.init(target: self, action: #selector(playerTapHander(handler:)))
        fdlPlayer.playerView.addGestureRecognizer(playerTap)
    }
    
    @objc func keyboardWillShow(noti: NSNotification) {
        LOGD(output: "\(#function)")
        if currentTextField == seekTextField {
            let point = CGPoint.init(x: scrollView.contentOffset.x, y: 160.0)
            scrollView.setContentOffset(point, animated: true)
        } else if currentTextField == speedTextField {
            let point = CGPoint.init(x: scrollView.contentOffset.x, y: 233.0)
            scrollView.setContentOffset(point, animated: true)
        }
    }
    
    @objc func keyboardWillHide(noti: NSNotification) {
        LOGD(output: "\(#function)")
        scrollView.contentOffset = CGPoint.zero
    }
    
    @objc func orientationChanged(noti: NSNotification) {
        guard fdlPlayer != nil else {
            return;
        }
                
        let device = noti.object as! UIDevice
        switch device.orientation {
        case .portrait, .portraitUpsideDown:
            LOGD(output: "\(#function) portrait.")
            fdlPlayer.playerView.frame = playerView.bounds
            break
        case .landscapeLeft, .landscapeRight:
            LOGD(output: "\(#function) landscape.")
            self.playerView.frame = self.view.bounds
            fdlPlayer.playerView.frame = self.view.bounds
            break
        default:
            break
        }
    }
    
    @objc func enterForeground(noti: NSNotification) {
        LOGD(output: "\(#function)")
        fdlPlayer.play()
    }
    
    @objc func enterBackground(noti: NSNotification) {
        LOGD(output: "\(#function)")
        fdlPlayer.pause()
    }
    
    @objc func tapHander(handler: UITapGestureRecognizer) {
        LOGD(output: "\(#function)")
        seekTextField.resignFirstResponder()
        speedTextField.resignFirstResponder()
        playButton.isHidden = true
    }
    
    @objc func panRecognized(_ recognizer: UIPanGestureRecognizer) {
        let distance = recognizer.translation(in: self.view)
        if recognizer.state == UIGestureRecognizer.State.changed {
            recognizer.cancelsTouchesInView = false
            let valueX = abs(distance.x)
            let valueY = abs(distance.y)
            let isUpDown = valueY > valueX;
            isUpDown ? self.panGestrueUpDown(distance: distance) : self.panGestureSwipe(distance: distance)
        } else if recognizer.state == UIGestureRecognizer.State.ended {
            LOGD(output: "\(#function) UIGestureRecognizerStateEnded")
            distanceX = 0.0;
            distanceY = 0.0;
        }
    }
    
    func panGestureSwipe(distance: CGPoint) {
        let value = distance.x - distanceX
        let absolute = abs(value)
        if value > 0 {
            /* right */
            if absolute > 5 {
                if isTimeShift == true {
                    fdlPlayer.setChangeFrameCh("pause", direction:"right")
                } else {
                    fdlPlayer.setChangeChannel("normal", direction: "right", moveFrame:1)
                }
            }
        } else {
            /* left */
            if absolute > 5 {
                if isTimeShift == true {
                    fdlPlayer.setChangeFrameCh("pause", direction:"left")
                } else {
                    fdlPlayer.setChangeChannel("normal", direction: "left", moveFrame:1)
                }
            }
        }
        distanceX = distance.x
    }
    
    func panGestrueUpDown(distance: CGPoint) {
        if isTimeShift == true {
            let value = distance.y - distanceY
            let absolute = abs(value)
            if  distance.y > 0 {
                /* down */
                if absolute > 5{
                    fdlPlayer.setChangeFrameCh("rewind", direction:"stop")
                }
            } else {
                /* up */
                if absolute > 5{
                    fdlPlayer.setChangeFrameCh("forward", direction:"stop")
                }
            }
        }
    }
    
    @objc func playerTapHander(handler: UITapGestureRecognizer) {
        LOGD(output: "\(#function)")
        self.playButton.isHidden = !self.playButton.isHidden
        self.playerView.bringSubviewToFront(self.playButton)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIDevice.current.orientation.isLandscape {
            LOGD(output: "Landscape")
        } else {
            LOGD(output: "Portrait")
        }
    }
    
    @objc func onTextFieldDoneButton(sender: UIBarButtonItem){
        seekTextField.resignFirstResponder()
        speedTextField.resignFirstResponder()
    }
    
    //MARK: PLAY/PAUSE
    @IBAction func onPlayback(_ sender: Any) {
        let button = sender as! UIButton;
        if  button.isSelected == true {
            button.isSelected = false
            fdlPlayer.pause()
        } else {
            if isPlaying == true {return}
            button.isSelected = true
            if isTimeShift == true {
                fdlPlayer.playToNow()
            } else {
                fdlPlayer.play()
            }
        }
    }
        
    @IBAction func onOpen(_ sender: Any){
        /* It is sample url, write a url to play. */
        let strUrl = "rtsp://RTSP Address." /* RTSP Address */
        fdlPlayer.streamOpen(strUrl, isTCP: true, isHWAccel: false);
    }
    
    @IBAction func onClose(_ sender: Any? = nil) {
        fdlPlayer.streamClose()
    }
    
    //MARK: MODE
    @IBAction func modeButtonTouchUpInside(_ sender: Any) {
        let button = sender as! UIButton
        if button.titleLabel?.text == " realtime " {
            button.setTitle(" timeshift ", for: UIControl.State.normal)
            isTimeShift = true
        } else if button.titleLabel?.text == " timeshift " {
            button.setTitle(" realtime ", for: UIControl.State.normal)
            isTimeShift = false
        }
    }
    
    //MARK: SWIPE
    @IBAction func leftButtonTouchUpInside(_ sender: Any) {
        let aString = swipTypeLabel.text
        let strTrim = aString?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        fdlPlayer.setChangeChannel(strTrim ?? "", direction: "left", moveFrame:1)
    }
    
    @IBAction func rightButtonTouchUpInside(_ sender: Any) {
        let aString = swipTypeLabel.text
        let strTrim = aString?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        fdlPlayer.setChangeChannel(strTrim ?? "", direction: "right", moveFrame:1)
    }
    
    @IBAction func swipTypeChangeVlue(_ sender: Any) {
        if swipTypeLabel.text == "normal" {
            swipTypeLabel.text = "bounce"
        } else if swipTypeLabel.text == "bounce" {
            swipTypeLabel.text = "normal"
        }
    }
    
    //MARK: TIME SHIFT
    @IBAction func pauseButtonTouchUpInside(_ sender: Any) {
#if true
        if isTimeShift {
            fdlPlayer.pause()
        } else {
            let message = "It is need to change mode 'timeshift'."
            self.showMessageAlert(message: message, title: "")
        }
#else
        let message = "This feature only applies to live versions."
        self.showMessageAlert(message: message, title: "")
#endif
    }
    
    @IBAction func forwardButtonTouchUpInsde(_ sender: Any) {
        if isTimeShift {
            self.setChangeFrameCh(playType: "forward") //playing forawrd
        } else {
            let message = "It is need to change mode 'timeshift'."
            self.showMessageAlert(message: message, title: "")
        }
    }
    
    @IBAction func rewindButtonTouchUpInsde(_ sender: Any) {
        if isTimeShift {
            self.setChangeFrameCh(playType: "rewind") //playing backward
        } else {
            let message = "It is need to change mode 'timeshift'."
            self.showMessageAlert(message: message, title: "")
        }
    }
    
    @IBAction func livePlayButtonTouchUpInside(_ sender: Any) {
#if true
        if isTimeShift {
            fdlPlayer.playToNow()
        } else {
            let message = "It is need to change mode 'timeshift'."
            self.showMessageAlert(message: message, title: "")
        }
#else
        let message = "This feature only applies to live versions."
        self.showMessageAlert(message: message, title: "")
#endif
    }
    
    func setChangeFrameCh(playType: String) {
        if modeButton.titleLabel?.text == " timeshift " {
            let aString = tsDirectButton.titleLabel?.text
            let strTrim = aString?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines) ?? ""
            fdlPlayer.setChangeFrameCh(playType, direction: strTrim)
        } else {
            let message = "It is need to change mode 'timeshift'."
            self.showMessageAlert(message: message, title: "")
        }
    }
    
    @IBAction func tsDirectButtonTouchUpInside(_ sender: Any) {
        let button = sender as! UIButton
        
        if button.titleLabel?.text == " left " {
            button.setTitle(" stop ", for: UIControl.State.normal)
            tsDirectLabel.text = "No chnage"
        } else if button.titleLabel?.text == " stop " {
            button.setTitle(" right ", for: UIControl.State.normal)
            tsDirectLabel.text = "Increase channel"
        } else if button.titleLabel?.text == " right " {
            button.setTitle(" left ", for: UIControl.State.normal)
            tsDirectLabel.text = "Decrease channel"
        }        
    }
    
    //MARK: SEEK
    @IBAction func seekButtonTouchUpInside(_ sender: Any) {
        if seekTextField.text!.count > 1 {
            fdlPlayer.seek(Int(seekTextField!.text ?? "0")!)
        } else {
            self.showMessageAlert(message: "Invalid seek value.", title: "")
        }
    }
    
    //MARK: ZAPPING
    @IBAction func pPositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_p")
    }
    
    @IBAction func cPositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_c")
    }
    
    @IBAction func onePositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_1")
    }
    
    @IBAction func twoPositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_2")
    }
    
    @IBAction func threePositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_3")
    }
    
    @IBAction func oneTwoPositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_1_2")
    }
    
    @IBAction func twoThreePositionButtonTouchUpInside(_ sender: Any) {
        self.setMovieZapping(position: "position_1_2")
    }
    
    func setMovieZapping(position: String) {
#if IS_SUPPORT_ZAPPING
        fdlPlayer.setMovieZapping(position)
#else
        let message = "The function is defined for a specific. so it do not support."
        self.showMessageAlert(message: message, title: "")
#endif
    }
    
    //MARK: SPEED
    @IBAction func speedButtonTouchUpInside(_ sender: Any) {
        let speed = Float(speedTextField!.text ?? "0")!
        if speed > 0 {
            if speed > 100 {
                let message = "More than 1x speed is not supported."
                self.showMessageAlert(message: message, title: "")
            } else {
                let value = speed * 0.01
                fdlPlayer.speed(CGFloat(value))
            }
        } else {
            let message = "Invalid input speed value.."
            self.showMessageAlert(message: message, title: "")
        }
    }
    
    //MARK: FDLivePlayer Delegate
    func getCurrentPlayInfo(_ channel: Int32, frame: Int32, frameCycle: Int32, time: Int32, utc: String) {
        DispatchQueue.main.async {
            if channel == 255 {
                /* The alternate screen when rise problem streaming on live. */
                //self.showMessageAlert(message: "Screen control is not available in the current state", title: "BirdView")
                print("\(#function) birdview.")
            }
            self.chLabel.text = NSString.localizedStringWithFormat("Play ch: %d", channel) as String;
            self.cycleLabel.text = NSString.localizedStringWithFormat("Cycle: %d", frameCycle) as String;
            self.frameLabel.text = NSString.localizedStringWithFormat("Frame: %d", frame) as String;
            self.timeLabel.text = NSString.localizedStringWithFormat("Time: %d", time) as String;
        }
    }
    
    func getVideoStreamInfo(_ width: Int32, height: Int32, duration: Int32) {
        LOGD(output: "\(#function) width: \(width) height: \(height) duration: \(duration).")
        let seconds = duration/1000
        var ms = NSMutableString.init(capacity: 8)
        if seconds < 0 {
            ms = "∞"
            return
        }
        let h = seconds / 3600
        ms.appendFormat("%d:", h)
        let m = seconds / 60 % 60
        if m < 10 {
            ms.append("0")
        }
        ms.appendFormat("%d:", m)
        let s = seconds % 60
        if s < 10 {
            ms.append("0")
        }
        ms.appendFormat("%d", s)
        LOGD(output: "\(#function) duration: \(ms).")
        DispatchQueue.main.async {
            self.duration.text = ms as String;
        }
    }
    
    func getStart(_ code: Int32) {
        LOGD(output: "\(#function) code: \(code).")
        isPlaying = true
    }
    
    func getStop(_ code: Int32) {
        LOGD(output: "\(#function) code: \(code).")
        isPlaying = false
        if isClose == true {
            fdlPlayer = nil
        }
    }
    
    func getPause() {
        LOGD(output: "\(#function)")
        isPlaying = false
    }
    
    func getPlayDone() {
        LOGD(output: "\(#function)")
        isPlaying = false
    }
    
    func getError(_ code: Int32, message: String) {
        LOGD(output: "\(#function) code: \(code) message: \(message)")
        DispatchQueue.main.async {[weak self] in
            guard let self = self else {return}
            if code == FD_ERR_NET_5001.rawValue {
                self.showMessageAlert(message: message, title: "BirdView")
            } else {
                self.showMessageAlert(message: message, title: "Error")
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        currentTextField = textField
    }
    
    func showMessageAlert(message: String, title: String) {
        let controller = UIAlertController.init(title: title ,
                                                message: message ,
                                                preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default) {(action) in
        }
        controller.addAction(okAction)
        self.present(controller, animated: true, completion: nil)
    }
}

