﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace FFmpeg.AutoGen
{
 
    public struct pp_mode
    {
    }

    public struct pp_context
    {
    }

    public struct _iobuf // FILE
    {
    }

    public struct size_t
    {
        public uint @value;
    }
}